## ----eval=FALSE------------------------------------------------------------
#  data(preCal.data)

## ----eval=FALSE------------------------------------------------------------
#  #check the first element
#  data(preCal.data)
#  preCal.data[[1]]

## ----eval=FALSE------------------------------------------------------------
#  ## try http:// if https:// URLs are not supported
#  source("https://bioconductor.org/biocLite.R")
#  biocLite("preCal.data")

## --------------------------------------------------------------------------
sessionInfo()

